// // nested folder
// const fs= require('fs');
// fs.mkdir('./AC',err=>{
//     if(err) throw err;
//     console.log("folder is created")
//     fs.mkdir('./AC/NotWorking',err=>{
//         if(err) throw err;
//         console.log("Nested folder is created")
//         fs.writeFile('./AC/NotWorking/callTechnician.js','Not Picking the call.....',err=>{
//             if(err) throw err;
//             console.log("file is created inside Nested folder")
//         })
//     })
// })





