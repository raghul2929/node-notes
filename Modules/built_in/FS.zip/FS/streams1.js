// Streams are collection of data like arrays or strings
// streams might not available all at once
// streams don't have to fit in memory
// Used to handle or manipulate the data like videos, large files etc...
// streams are used to transfer the data chunk by chunk