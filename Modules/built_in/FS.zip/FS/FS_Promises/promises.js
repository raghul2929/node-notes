const fs= require('fs/promises')
// fs.readFile('./promise.txt','utf-8')
// .then((data)=>{console.log(data)})
// .catch((err)=>{console.log(err)})

// fs.writeFile('./AC_Not_Working','We are Feeing too Cold......')
// .then(_=>{console.log("file is created and written")})
// .catch((err)=>{console.log(err)})

// read n write File
// rename a File
// delete a File
// change file extention
// create a folder
// create nested folder
// create file inside a folder
// rename folder
// delete folder